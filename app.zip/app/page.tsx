"use client"

// pages/index.tsx

import Sidebar from "@/components/Sidebar";
import MainContent from "@/components/MainContent";
import Head from "next/head";

import { Provider } from 'react-redux';
import { store } from '@/store/store';

const Home = () => {
  return (
    <Provider store={store}>
      <div className="flex h-screen">
        <Head>
          <title>Financial Recommendation System</title>
          <link rel="icon" href="/favicon.ico" />
        </Head>
        <Sidebar />
        <MainContent />
      </div>
    </Provider>
  );
};

export default Home;

