import { openai } from '@ai-sdk/openai';
import { StreamingTextResponse, streamText } from 'ai';
import { promises as fs } from 'fs';
import path from 'path';

// Initialize the OpenAI client with your API key and model

export async function POST(req: any) {
  const { messages } = await req.json();

    const jsonDirectory = path.join(process.cwd(), 'public');
    const fileContents = await fs.readFile(path.join(jsonDirectory, 'crm.json'), 'utf8');

  const lastMessage = messages[messages.length - 1];
  const query = lastMessage.content;
  const full_prompt = `You are the chatbot for a customer relationship management (CRM) system. The system is used to manage customer relationships. The chatbot will provide you with information about the data inside the crm context ${fileContents}. based on this context, you will be able to answer questions about the data. ${query}`;

  messages[messages.length - 1] = { role: 'user', content: full_prompt }

  console.log("messages", messages);

  try {
    // Use the OpenAI client to send the streaming text request
    const result = await streamText({
      model: openai("gpt-4-turbo"),
      messages,
    });

    console.log("messages", messages);

    // Return the streaming text response
    return new StreamingTextResponse(result.toAIStream());
  } catch (error) {
    // Handle any errors
    console.error("Error:", error);
    return new Response("Internal Server Error", { status: 500 });
  }
}
